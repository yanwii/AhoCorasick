#ifndef TRIETREE
#define TRIETREE

#include <iostream>
#include <vector>
using namespace std;

typedef struct ChildNode{
    public:
    string word;
    unordered_map<string, ChildNode*> child;
    int state=0;
    int depth;
    bool is_end = false;
    string segment;
} Node;

class TrieTree{
    public:
    TrieTree(){
        proot = new Node();
    }
    Node* proot;
    int index=0;
    public:
    void add_words(vector<string>, bool);
    void prefix_search(string &text);
};


#endif
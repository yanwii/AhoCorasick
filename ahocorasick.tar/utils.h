#ifndef TTA_UTILS
#define TTA_UTILS

#include <iostream>
#include <vector>
using namespace std;

vector<vector<string>> cut(vector<string>);
vector<string> cut(string);
vector<string> read_file(string);
#endif